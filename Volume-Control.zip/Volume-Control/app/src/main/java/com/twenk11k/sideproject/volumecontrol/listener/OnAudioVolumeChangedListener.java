package com.twenk11k.sideproject.volumecontrol.listener;

public interface OnAudioVolumeChangedListener {

    void onAudioVolumeChanged(int currentVolume, int maxVolume);
}